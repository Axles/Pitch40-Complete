package com.pitchaddon.mixin;

import com.pitchaddon.modules.CustomPitch40;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_340;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(class_340.class)
public class DebugHudMixin {

    @Inject(method = "getLeftText", at = @At("RETURN"))
    private void onGetLeftText(CallbackInfoReturnable<List<String>> cir) {
        CustomPitch40 module = Modules.get().get(CustomPitch40.class);
        if (module == null || !module.isActive() || !module.showSpeedInF3.get()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        class_243 vel = mc.field_1724.method_18798();
        double horizontal = Math.sqrt(vel.field_1352 * vel.field_1352 + vel.field_1350 * vel.field_1350) * 20.0;
        double vertical = vel.field_1351 * 20.0;
        double total = Math.sqrt(vel.field_1352 * vel.field_1352 + vel.field_1351 * vel.field_1351 + vel.field_1350 * vel.field_1350) * 20.0;

        List<String> list = cir.getReturnValue();
        list.add("");
        list.add(String.format("Speed: %.2f b/s (H: %.2f  V: %.2f)", total, horizontal, vertical));
    }
}